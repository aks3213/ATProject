const { Movie }=require('./Movie.model');
const {User}=require('./user.model');

module.exports = {
    Movie,
    User
}