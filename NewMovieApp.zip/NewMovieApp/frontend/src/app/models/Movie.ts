export class IMovie{
    title: string;
    _id:string;

    genre:string;
    details:string;

    size:number;
    quality:number;
/*
    public get getTitle() {
        return this.title;
    }
    public get getId() {
        return this._id;
    }

    public get getGenre() {
        return this.genre;
    }

    public get getSize() {
        return this.title;
    }

    */

}