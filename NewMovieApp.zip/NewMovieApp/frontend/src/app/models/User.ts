export class IUser{
    email: string;
    password:string;
}